﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoClub.DAL;
using AutoClub.Models;
using Microsoft.AspNetCore.Mvc;

namespace AutoClub.Controllers
{
    public class ContactController : Controller
    {
        private readonly AppDbContext _db;
        public ContactController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            WebSiteBio webSiteBio = _db.WebSiteBios.FirstOrDefault(wsb => wsb.Id == 1);
            return View(webSiteBio);
        }
    }
}