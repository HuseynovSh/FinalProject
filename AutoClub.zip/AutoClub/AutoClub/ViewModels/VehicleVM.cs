﻿using AutoClub.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutoClub.ViewModels
{
    public class VehicleVM
    {
        public Vehicle Vehicle { get; set; }
        public VehicleFeatures VehicleFeatures { get; set; }
    }
}
