﻿using AutoClub.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutoClub.ViewModels
{
    public class ContactVM
    {
        public WebSiteBio webSiteBio { get; set; }
        public ContactMessage contactMessage { get; set; }
    }
}
