﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutoClub.Role
{
    public static class UserRole
    {
        public enum Roles
        {
            Admin,
            Member,
            User,
            Company
        }
    }
}
